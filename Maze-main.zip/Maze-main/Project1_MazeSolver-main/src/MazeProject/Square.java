package MazeProject;

public enum Square {
    START,
    EXIT,
    WALL,
    OPEN_SPACE
}
